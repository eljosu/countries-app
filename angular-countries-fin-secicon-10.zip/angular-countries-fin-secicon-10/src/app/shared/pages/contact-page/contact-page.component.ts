import { Component } from '@angular/core';

@Component({
  selector: 'shared-contact-page',
  templateUrl: './contact-page.component.html',
  styles: [
  ]
})
export class ContactPageComponent {

}

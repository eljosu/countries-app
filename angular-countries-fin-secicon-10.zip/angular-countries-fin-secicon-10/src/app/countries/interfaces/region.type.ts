

export type Region = 'Africa'|'Americas'|'Asia'|'Europe'|'Oceania'| '';

import { Component } from '@angular/core';

@Component({
  selector: 'shared-about-page',
  templateUrl: './about-page.component.html',
  styles: [
  ]
})
export class AboutPageComponent {

}
